

#! /usr/local/bin perl

use strict;



#our $KPAX_EXECUTABLE         = "/data/elevy/00_bin/kpax-centos/bin/kpax -noalign -nopdb -nokpax -threads -broken";
our $KPAX_EXECUTABLE         = "./bin/kpax -noalign -nopdb -nokpax -threads -broken";
our $BU_RES_RENUM            = "./pdb/";    # path for target structures ????_1.pdb
our $BU_PISA		     = "./pdb_pisa/";	# path for target structures taken from pisa ????_1p.pdb
our $PATH_BU_SPLIT	     = "./pdb_split/"; # path for target structures splitted into separate chains ????_1_A.pdb

our $T_CUT	  	     = 0.65; # TM SCORE CUT OFF, for selecting good targets and similar structures for the query

sub load_PDBs($$){

    my ($name_list, $save_interface) = @_;
    my %pdb ;
    my $counter=0 ;
    my $smallest_chain = 22;
    my ($name);

    #print STDERR "Loading the PDBs from " ;
    #print STDERR "\"".$name_list->[0]."\" to \"".$name_list->[-1]."\" ...";

    foreach $name (@{$name_list}){

        my ($ch_name, $r_name, $a_name, $r_num, $a_num, $x, $y, $z, $ALTERN) ;
        my ($line, $ch_size) ;
        my $ch_name_tmp = "";
        my $r_name_tmp  = "";
        my $r_num_tmp   = "";
        my $ALTERN_TMP  = "";
        my $to_skip     = -1;

        $name =~ s/ //g;

        if( $name =~ m{/}){
            open (PDB_FH, $name) or print STDERR "$name could not be opened in load_PDBs - $!\n";
        } elsif($name =~ /_p1/)
	 {
		open (PDB_FH, $::BU_PISA.$name) or print STDERR "$::BU_PISA $name could not be opened in load_PDBs - $!\n";
	}
	else{	
            #print STDERR "Be carreful, PDB is loaded from default directory $::BU_all_renum\n";
            open (PDB_FH, $::BU_RES_RENUM.$name) or print STDERR "$::BU_RES_RENUM $name could not be opened in load_PDBs - $!\n";
        }

        # ---- print the prgression as points
        if ($counter%100 == 0 && $counter !=0){
            #print STDERR "\n";
        }
        if( $counter%10 == 0 && $counter !=0){
            #print STDERR "."
        }
        $counter+=1 ;
        # -----------------------------------
        #    print STDERR $name."\n";  # -- debug

        $ch_size = 0 ;

        ## This is the index used to reprint the PDB later on.
        my $line_index = 0;


        # ---- goes through the PDB file and load the atoms & positions in a hash
        while(<PDB_FH>){

            $line = $_;
            if ($line=~/^ATOM/ && (substr($line,16,1) eq " " ||  substr($line,16,1) eq "A")){
                $ch_name= substr($line,21,1);

                if($ch_name_tmp eq ""){
                    $ch_name_tmp=$ch_name ;
                }
                if($ch_name ne $ch_name_tmp){ # -- then a new chain just arrived

                    # ---- this is to look if the chain is a protein or something else
                    # ---- if it is something else (no Calpha), we remove the entry
                    if($ch_size < $smallest_chain){
                        delete $pdb{$name}->{$ch_name_tmp};
                        $ch_size = 0 ;
                    } else {
                        $pdb{$name}->{$ch_name_tmp}->{"size"}=$ch_size ;
                        $ch_size = 0 ;

                        ### 
                        ### I need to check that the order of chain in the original PDB is increasing - otherwise there will be bugs.
                        ###
                        if ( $::chain_number{$ch_name_tmp} > $::chain_number{$ch_name} ){
                            #print STDERR "There is a problem in $name, $ch_name_tmp ($::chain_number{$ch_name_tmp}) is after $ch_name ($::chain_number{$ch_name}) but chains should always appear in the following order in the PDB file: A->Z, a->z, 0->9\n";
                        }
                    }
                    $ch_name_tmp=$ch_name ;
                }

                $a_num  = substr($line,7,4);  # --- Changes at each line
                $a_name = substr($line,11,5);
                $x      = substr($line,30,8);
                $y      = substr($line,38,8);
                $z      = substr($line,46,8); # This has changed!!! BE CAREFULLLLLL AGAIN CHANGED FROM 7 TO 8

                $r_name = substr($line,17,4); # --- Changes at each residue / chain
                #$ALTERN = substr($line,16,1); # --- If there is an ambiguity, ALTERN can take A,B,C ... values.
                $r_num  = substr($line,22,5);

                # --- Remove white spaces
                $a_num  =~ s/ //g ;
                $a_name =~ s/ //g ;
                $r_name =~ s/ //g ;
                $ch_name=~ s/ //g ;
                $r_num  =~ s/ //g ;
                $x      =~ s/ //g ;
                $y      =~ s/ //g ;
                $z      =~ s/ //g ;

                # --- if wanted, add the line to
                # --- print the interface
                if( $save_interface == 1){
                    if($a_name eq "CA"){
                        $pdb{$name}->{$ch_name}->{"lines"}->{$r_num}->{"CA"} = $line ;
                    }
                    $pdb{$name}->{$ch_name}->{"lines"}->{$r_num}->{$line_index++} = $line ;
                }
                # ATOM   3944  N   TYR H 100A      2.196  19.583 107.279  1.00 18.94           N
                # ---- Sometimes, people are really dumb ... and put the A,B,C ALTERN stuff AFTER the residue number.
                # ---- --> So In that case I put it back in the right format.
                if($r_num =~ /^(-{0,1}[0-9]+)([a-zA-Z])$/){
                    $r_num  = $1.$2;     # This is to keep all residues distinct
                    #$ALTERN = $2;
                } elsif(! ($r_num =~ /^-{0,1}[0-9]+$/) ){
                    print STDERR $r_num." has not been recognized in pdb $name\n";
                }

                #if($ALTERN eq " "){
                #    $ALTERN_TMP = "OK";
                #}

                if( ($r_num_tmp ne ""  && $r_num_tmp == $r_num && $r_name_tmp ne $r_name) ||    # if resid def and same resid number but different name
                    $to_skip == $r_num  ##||
                    ##(exists($pdb{$name}->{$ch_name}->{$r_num}) && $ALTERN ne " " && $ALTERN ne "A" && $ALTERN_TMP ne "")        
                    # This last condition is to skip residues with alternative defs but some
                    # prots like 2g0x are entirely alternatively def ... so I hate PDBs - so I add the conditions 
                    # that 
                    # -1/ a TRUE RESIDUE (with no ALTER DEF) must have been seen in order to make the condition true.               
                    # -2/ ALTERN must be different than A --> so B/C/D etc are skipped, but A is kept.
                    #
                    # Actually, a simpler solution is to only consider to OK lines to start with
                    ){
                    # Do nothing, because this is a second def for the same resid
                    #print " $r_num_tmp == $r_num && $r_name_tmp ne $r_name ".$line;
                    $to_skip=$r_num;
                    #$ALTERN_TMP = $ALTERN;

                } else {

                    $to_skip=-1;
                    ######################################
                    if($a_name =~ "CA"){          ### --- Special treatment for the Ca
                        ### --- we index them
                        $ch_size+=1;                ### --- chain size
                        ######################################

                        #print STDERR "YOYOMA\n";

                        # --- if first time init the list
                        if( ! exists($pdb{$name}->{$ch_name}->{"x"})){
                            $pdb{$name}->{$ch_name}->{"x"}=[[$x,$r_num]];
                            $pdb{$name}->{$ch_name}->{"y"}=[[$y,$r_num]];
                            $pdb{$name}->{$ch_name}->{"z"}=[[$z,$r_num]];
                        } else {                    # --- else add residues to it
                            push(@{$pdb{$name}->{$ch_name}->{"x"}},[$x,$r_num]);
                            push(@{$pdb{$name}->{$ch_name}->{"y"}},[$y,$r_num]);
                            push(@{$pdb{$name}->{$ch_name}->{"z"}},[$z,$r_num]);
                        }
                    }

                    # --- add all atoms
                    $pdb{$name}->{$ch_name}->{$r_num}->{$a_name}->{"x"}=$x;
                    $pdb{$name}->{$ch_name}->{$r_num}->{$a_name}->{"y"}=$y;
                    $pdb{$name}->{$ch_name}->{$r_num}->{$a_name}->{"z"}=$z;

                    # --- and the name of the corresponding residue
                    $pdb{$name}->{$ch_name}->{$r_num}->{"Rname"}=$r_name ;   ### XXX must be carrefull when looking at KEYS of r_num!!!

                }
                $r_num_tmp = $r_num;
                $r_name_tmp = $r_name;
            }
        }

        # ---- this is to look if the chain is a protein or something else
        # ---- if it is something else (no Calpha), we remove the entry
        if($ch_size < $smallest_chain){
            delete $pdb{$name}->{$ch_name};                # XXX I think it should be ch_name not tmp
            $ch_size = 0 ;
        } else {
            $pdb{$name}->{$ch_name}->{"size"}=$ch_size ;   # XXX I think it should be ch_name not tmp
            $ch_size = 0 ;
        }
    }

    # --- Sort the x, y, z coordinates of each residue
    my ($pdb1, $chain, @nbChains);

    foreach $pdb1 (keys %pdb){

        @nbChains = keys %{$pdb{$pdb1}} ; # If it is not at leat a dimer

        # if($#nbChains >=1){

        foreach $chain (@nbChains){
            @{$pdb{$pdb1}->{$chain}->{"x"}} = sort {$a->[0]<=>$b->[0]} @{$pdb{$pdb1}->{$chain}->{"x"}} ;
            @{$pdb{$pdb1}->{$chain}->{"y"}} = sort {$a->[0]<=>$b->[0]} @{$pdb{$pdb1}->{$chain}->{"y"}} ;
            @{$pdb{$pdb1}->{$chain}->{"z"}} = sort {$a->[0]<=>$b->[0]} @{$pdb{$pdb1}->{$chain}->{"z"}} ;
        }
        #    } else {
        #      delete $pdb{$pdb1};
        #    }
    }
    return \%pdb ;
}



###
### Takes a path to a PDB file and returns a HASH giving correspondances between chain names and chain order.
###
sub map_chain_name_num($){

    my ($name) = @_;

    open (PDB_FH, $name) or die($name);

    my ($ch_name, $line);
    my $ch_name_tmp = "";
    my $ch_number = 0;
    my %H_ch_num = ();

    while(<PDB_FH>){
        $line = $_;
        if ($line=~/^ATOM/){

            $ch_name= substr($line,21,1);

            if($ch_name_tmp eq ""){
                $ch_name_tmp=$ch_name ;

                if(! exists $H_ch_num{$ch_name}){
                    $H_ch_num{$ch_name}=$ch_number++;
                }
            }
            if($ch_name ne $ch_name_tmp){ # -- then a new chain just arrived
                if(! exists $H_ch_num{$ch_name}){
                    $H_ch_num{$ch_name}=$ch_number++;
                }
            }
        }
    }
    return(\%H_ch_num);
}



sub get_close($$$$$$$){

  my ($pdbs, $name, $x_1, $y_1, $z_1, $rc, $CH2) = @_ ;
  #print STDERR "GET close : $pdbs, $name, $x_1, $y_1, $z_1, $rc, $CH2 \n";
  my ($d, $ar, $elmt, $inf, $sup, $pos_inf, $pos_sup) ;
  my %x_ok=() ;
  my %y_ok=() ;
  my %z_ok=() ;

  # --- First look wether ...
  if ( $pdbs->{$name}->{$CH2}->{"x"}->[0][0] - $rc > $x_1 ||
       $pdbs->{$name}->{$CH2}->{"x"}->[-1][0] + $rc < $x_1 ||
       $pdbs->{$name}->{$CH2}->{"y"}->[0][0] - $rc > $y_1 ||
       $pdbs->{$name}->{$CH2}->{"y"}->[-1][0] + $rc < $y_1 ||
       $pdbs->{$name}->{$CH2}->{"z"}->[0][0] - $rc > $z_1 ||
       $pdbs->{$name}->{$CH2}->{"z"}->[-1][0] + $rc < $z_1
     ) {
    # --- if one of these conditions is true then $R1 can't be in contact with 
    # --- any residue of the chain 2
    my @empty ;
    return \@empty ;
  } else {
    # --- else, we look for the potential residues in contact (included in the bowl)

    ## --- look for wich residues have their X coord inside the bowl
    $inf = $x_1 - $rc ;
    $sup = $x_1 + $rc ;

    $pos_inf = dichoSearch($inf, $pdbs->{$name}->{$CH2}->{"x"});
    $pos_sup = dichoSearch($sup, $pdbs->{$name}->{$CH2}->{"x"});

    for $elmt ($pos_inf..$pos_sup){
      $ar = $pdbs->{$name}->{$CH2}->{"x"}->[$elmt] ; # Those "CA" that are OK on X
      $x_ok{$ar->[1]}= ($x_1 - $ar->[0])**(2);
    }

    ## --- look for wich residue having their x coord that is inside the bowl,
    ## --- have also their Y coord inside the bowl
    $inf = $y_1 - $rc ;
    $sup = $y_1 + $rc ;

    $pos_inf = dichoSearch($inf, $pdbs->{$name}->{$CH2}->{"y"});
    $pos_sup = dichoSearch($sup, $pdbs->{$name}->{$CH2}->{"y"});

    for $elmt ($pos_inf..$pos_sup){
      $ar = $pdbs->{$name}->{$CH2}->{"y"}->[$elmt] ;
      if( exists $x_ok{$ar->[1]} ){
        $y_ok{$ar->[1]}= $x_ok{$ar->[1]} + ($y_1-$ar->[0])**(2);
      }
    }
    ## -- same for Z
    $inf = $z_1 - $rc ;
    $sup = $z_1 + $rc ;

    $pos_inf = dichoSearch($inf, $pdbs->{$name}->{$CH2}->{"z"});
    $pos_sup = dichoSearch($sup, $pdbs->{$name}->{$CH2}->{"z"});

    for $elmt ($pos_inf..$pos_sup){
      $ar = $pdbs->{$name}->{$CH2}->{"z"}->[$elmt] ;
      if( exists $y_ok{$ar->[1]}){
        $d = sqrt( $y_ok{$ar->[1]} + ($z_1 - $ar->[0])**(2) ) ;
        if ( $d < $rc){
          $z_ok{$ar->[1]}= $d;
          # print STDERR "PDB = $name, ORIG = $x_1, $y_1, $z_1, Found=Resid number ".$ar->[1].", cut = $d\n";
        }
      }
    }

    my @good_res  = keys(%z_ok) ;
    return \@good_res ;
  }
}


sub dichoSearch($$){
  my ($toFind, $array) = @_ ;
  my ($oldIndex, $newIndex) =($#{$array},0);
  my ($temp,$direction)=(0,1) ;
  my $i=0;

  while( $i< $#{$array}+1){
    $i++;
    #print STDERR "INDEX : $newIndex, array : ".join(", ",@{$array})."-> array[0] = $array->[0]\n";
    #print STDERR "toFind ; $toFind\n";
    if($array->[$newIndex][0] == $toFind){
      return $newIndex ;
    }

    $temp = $newIndex ;
    $newIndex = int( ($newIndex+$oldIndex)/2 ) ;

    if($newIndex == $temp){

      if($#{$array} > 0){

        if( $array->[$newIndex+1][0] > $toFind){
          return $newIndex;
        } else {
          return $newIndex+1;
        }

      } else {

        if($toFind > $array->[$newIndex][0]){
          return 1 ;
        } else {
          return 0;
        }
      }
    }

    if($direction == 1){ # Then we come from the left

      if( $array->[$newIndex][0] > $toFind ){ # Then have to go to the left
        # So the direction changes to opposite
        $oldIndex = $temp ;
        $direction = -1 ;
      }
    }
    elsif($direction == -1){ # Then we come from the right

      if( $array->[$newIndex][0] < $toFind ){ # Then have to go to the right
        # So the direction changes
        $oldIndex = $temp ;
        $direction = 1 ;
      }
    }
  }
  print STDERR "ERROR IN DICHO SEARCH\n";
}





sub write_PDB_kpax($$){

    my ($PDB_H, $chain_def) = @_;

     foreach my $PDB (keys %$PDB_H){

         #print STDERR "$PDB\n";

        if(! ($PDB =~ /query/) ){

            my @chain_num = sort {$a <=> $b} keys %{$chain_def->{$PDB}} ;

            my ($REF, $code_tmp, $pdb_tmp);
            ##             REF     CODE
            if($PDB =~ /\/([^\/]+)\/([^\/]+.pdb)$/){
                $REF      = $1;
                $pdb_tmp  = $2;
                $code_tmp = $2;

                ## to get the name of the temporary code, I delete the constant part corresponding to the ref name
                $code_tmp =~ s/_$REF.pdb//;
            }

            #print STDERR "REF = $REF, pdb_tmp = $pdb_tmp , code_tmp = $code_tmp \n";

            if ( ! -e $ENV{KPAX_RESULTS}."$REF/pdbs"){
                mkdir($ENV{KPAX_RESULTS}."$REF/pdbs")
            }

            my $PDB2 = $ENV{KPAX_RESULTS}."$REF/pdbs/$code_tmp.pdb";

            open(PDBOUT, ">$PDB2") or die ("cannot open $PDB2 : $!\n");
            my $all_pdb = "";
            foreach my $num (@chain_num){

                ## Writes the file.             
                # $pdb{$name}->{$ch_name}->{"lines"}->{$r_num}->{$line_index} = $line ;

                my $current_chain = $chain_def->{$PDB}->{$num};

                my @residues_index = sort {$a <=> $b} keys %{$PDB_H->{$PDB}->{$current_chain}->{"lines"}};

                foreach my $resid (@residues_index){

                    my @line_index = sort {$a <=> $b} keys %{$PDB_H->{$PDB}->{$current_chain}->{"lines"}->{$resid}};

                    foreach my $line_i (@line_index){

                        $all_pdb .= $PDB_H->{$PDB}->{$current_chain}->{"lines"}->{$resid}->{$line_i};
                        delete $PDB_H->{$PDB}->{$current_chain}->{"lines"}->{$resid}->{$line_i};
                    }
                }
            }

            print PDBOUT $all_pdb;
            close(PDBOUT);
        }
    }
}

### Takes 2 hashes defining a sparse matrix and returns a HASH defining BI-directional best hits.
### as well as non defined values.
###
### HASH1 = ROWS
### HASH2 = COLS
###
sub BDBH($$){

    my ($H1, $H2) = @_ ;

    #print "H1=".Dumper($H1);
    #print "H2=".Dumper($H2);

    my $H1_rank = H_2_rank($H1);
    my $H2_rank = H_2_rank($H2);

    #print "H1 rank=".Dumper($H1_rank);
    #print "H2 rank=".Dumper($H2_rank);

    my $H_bdbh;
    my $H_bdbh_rev;

    foreach my $ch1 (keys %$H1_rank) {

        foreach my $ch2 (keys %{$H1_rank->{$ch1}}) {

            if ($H1_rank->{$ch1}->{$ch2} == 1 && $H2_rank->{$ch2}->{$ch1} == 1 ){

                $H_bdbh->{$ch1}=$ch2;
                $H_bdbh_rev->{$ch2}=$ch1;
            } else {

                #$H_bdbh->{$ch1}->{$ch2}=0;

            }
        }
    }

    return ($H_bdbh,$H_bdbh_rev);
}

###
### Takes a hash of the form H ->{A}->{v1}->score1
###                                \->{v2}->score2
###                           \->{B}->{v1}->score1 etc ...
###
### Transforms the scores into ranks.
###
sub H_2_rank($){

    my ($Hs) = @_;

    my $H_res;

    foreach my $k1 (keys %$Hs){

        my @keys2 = keys %{$Hs->{$k1}};
        my @pairs = ();

        foreach my $k2 (@keys2){

            push(@pairs, [$k2, $Hs->{$k1}->{$k2}]);
        }

        my @sorted_pairs = sort { $b->[1] <=> $a->[1] } @pairs;

        my $rank=1;

        foreach my $pair (@sorted_pairs){

            $H_res->{$k1}->{$pair->[0]} = $rank;
            $rank++;
        }
    }
    return $H_res;
}

# return the standard deviation
# (Sum_i( (x_i - X)^2/n-1 ))^0.5
#
sub SD($){

  my ($array) = @_;
  my $mean = MEAN($array);
  my $sum = 0;
  map {$sum += ($_ - $mean)**2 } @$array ;

  if($sum == 0){
    return "0";
  } elsif($#{$array}+1 == 0 || $#{$array} == 0){
    return "NaN";
  } else {
    return sqrt($sum / $#{$array}) ;
  }
}

# return the Variance
# (Sum_i( (x_i - X)^2/n-1 ))
#
sub VAR($){

  my ($array) = @_;
  my $mean = MEAN($array);
  my $sum = 0;
  map {$sum += ($_ - $mean)**2 } @$array ;

  if($sum == 0){
    return "0";
  } elsif($#{$array}+1 == 0){
    return "NaN";
  } else {
    return $sum / $#{$array} ;
  }
}


# Returns the mean of an array
sub MEAN($){

  my ($array) = @_ ;
  my $sum =0;
  map { $sum += $_ } @$array ;
  if($sum == 0){
    return "0";
  } elsif($#{$array}+1 == 0){
    return "NaN";
  } else {
    return $sum/($#{$array}+1);
  }
}

# Returns the sum of an array
sub SUM($){

  my ($array) = @_ ;
  my $sum =0;
  map { $sum += $_ } @$array ;
  return $sum;
}

# Take 2 values, return the smallest one
sub min($$){
  my ($a, $b)= @_;
  if($a < $b){
    return $a;
  } else {
    return $b;
  }
}

# Take 2 values, return the biggest one
sub max($$){
  my ($a, $b) = @_ ;
  if($a > $b){
    return $a ;
  } else {
    return $b ;
  }
}

# Returns the max of an array
sub MAX($){

  my ($array) = @_ ;
  my $max = $array->[0];
  map { $max = max($max, $_) } @$array ;
  return $max;
}

# Returns the min of an array
sub MIN($){

  my ($array) = @_ ;
  my $min = $array->[0];
  map { $min = min($min, $_) } @$array ;
  return $min;
}

1;
