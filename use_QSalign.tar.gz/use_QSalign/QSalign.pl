# The program takes a query PDB, looks for good targets from the "target_file.txt", does full QS alignment against the good targets
# Make the "target_file.txt" with 2 columns -- 1) the desired target codes 2)num of sub-units/chains of the target
# T-SCORE CUT-OFF ($T-CUT) OF 0.65 IS USED FOR SELECTING GOOD TARGETS (SIMILAR STRUCTURES) 
# SD
# 18.07.17

#!/usr/bin/perl
use strict;
use Data::Dumper ;
require("./kpax.pm");

# USAGE :    perl QSalign.pl full_path/query.pdb num_of_SU target_file
#    e.g:    perl QSalign.pl /home/my_dir/5rub_1.pdb 2 target_file.txt

# OUTPUT:    ./QSalign_results/5rub_1.QSalign_out



$ENV{KPAX_RESULTS} = '/tmp/';



#my $ALL_TARGET_FILE = "target_file.txt_all";   # INPUT FILE containing all targets from PDB and PISA (homo=1 or 2) and nsub2 (no. of subunits)
my $ALL_TARGET_FILE = $ARGV[2];   # INPUT TARGET FILE containing all targets and no. of subunits

#my $T_CUT=0.65; # TM SCORE CUT OFF, for selecting good targets for the query


my $start_run = time();

my $query=$ARGV[0]; # query structure with full path
my $ns=$ARGV[1];    # number of subunits in the query structure


my $q_path; my $q_pdb;my $tm;my $q_code;
if ($query=~/(.*\/)((.*)\.pdb)/)
{
	$q_path=$1; $q_pdb = $2;$q_code=$3;
}

my $target_file="./target_file_$q_code";
my $log_file="./good_targets_$q_code.log";

system("mkdir QSalign_LOG");

system("mkdir QSalign_results");
my $output=$q_pdb; 
$output=~s/pdb/QSalign_out/;  # output file

my $logdir="./QSalign_LOG";


open(LOG, ">$logdir/$log_file");
open(TARGET, ">$target_file");

print "user query - $query  $ns \n";

# ---- loading query pdb, and extracting only one chain
my $PDB_LIST = []; 
push  @$PDB_LIST, $query;
my $q_pdb_href = load_PDBs($PDB_LIST, 1);
my %q_pdb_hash=%$q_pdb_href; # deref hash



#print "Dereferenced: \n";

    foreach my $k (keys %q_pdb_hash) {
	foreach my $ch (keys $q_pdb_hash{$k}){
		my $size = keys $q_pdb_hash{$k};
#		print "$k: no.of chs $size \n";
 #       	print "$k: $ch: $q_pdb_hash{$k}{$ch}\n";
		if($size > 1){
		delete ($q_pdb_hash{$k}{$ch});
	
	}	
	my $size = keys $q_pdb_hash{$k};
#	print "After delete $k: no.of chs $size \n";
    }
}
  # for checking the ch size only
foreach my $k (keys %q_pdb_hash) {
        foreach my $ch (keys $q_pdb_hash{$k}){
                my $size = keys $q_pdb_hash{$k};
#               print "NOW AFTER DELETE $k: no.of chs $size \n";
		}
}

	# Now write it to a temp query file
	my $q_pdb2=$q_pdb;
	substr($q_pdb2,-4,4,"_tmp.pdb");
	my $query2 = "$q_path"."$q_pdb2";
#	print "QUERY 2 -- $query2\n";
	open(PDBOUT, ">$query2") or die ("cannot open $query2 : $!\n");
	my $all_pdb = "";
	foreach my $k (keys %q_pdb_hash) {
		foreach my $ch (keys $q_pdb_hash{$k}){
			my @residues_index = sort {$a <=> $b} keys %{$q_pdb_href->{$k}->{$ch}->{"lines"}};
			foreach my $resid (@residues_index){
				my @line_index = sort {$a <=> $b} keys %{$q_pdb_href->{$k}->{$ch}->{"lines"}->{$resid} };
				foreach my $line_i (@line_index){
					$all_pdb .=$q_pdb_href->{$k}->{$ch}->{"lines"}->{$resid}->{$line_i};
					delete $q_pdb_href->{$k}->{$ch}->{"lines"}->{$resid}->{$line_i};
		#	foreach my $lines ( keys %{$q_pdb_hash{$k}{$ch}{"lines"}}){
		#		foreach my $resid ( keys %{$q_pdb_hash{$k}{$ch}{$lines} }){
		#	print "$k:$ch:lines : $q_pdb_hash{$k}{$ch}{$lines}{$resid} \n";
			}
			}
			}
			}
		print PDBOUT $all_pdb;
            	close(PDBOUT);




#my @tmp = keys %$q_pdb_href;
#print STDERR "KEYS = @tmp \n";
#print "PDBs = ".Dumper($q_pdb_href);



# Look for good targets (aligining only one chain -- query2 has 1 with target chain A) from the file created from 3dComplex (homo="1" and nsub2 > 1)
open(FH1, "$ALL_TARGET_FILE");

print "Running first alignment \n";

my $all_target_size = @{[<FH1>]};
#print $all_target_size,"\t";
my $cnt=0;my $target_path;


seek FH1, 0, 0;
while(<FH1>)
{
	$cnt++;
	print "$cnt/$all_target_size all targets\n";
	if($_=~/^((\w\w\w\w)_*p{0,1}\d*)\s+(\d+)/)   # to match codes both from pdb and pisa
	{
		my $t_pdb=$1; my $t_pdb_code=$2; my $ns_temp=$3; #my $pi=$3;
		#print "code $t_pdb_code, t $t_pdb, ns $ns_temp\n";
		if($ns == $ns_temp)
		{
				
		#	my $q_pdb = load_PDBs($query, 1);		
			#print "q-- $q_pdb t-- $t_pdb ns-- $ns\n";
			# Set the target paths for pdb and pisa as t_pdb becomes same ie ????_1_A later
			if($t_pdb =~/_p\d/)  #changed from p1 tp _p\d
			{
				$target_path="$::BU_PISA"."$t_pdb.pdb";
			}
			else
			{
				$target_path="$::BU_RES_RENUM"."$t_pdb.pdb";
			}
			# run kpax
			run_kpax_good_targets($query2, $t_pdb);

			open(FH2,"/tmp/kpax.log");
			while(<FH2>)
        		{
                		if ($_=~/.*$t_pdb_code.*\_A\[/  && (substr($_,41,6) > $::T_CUT))  # selecting good targets, cut-off can be changed
                		{
                        		$tm = substr($_,41,6);
                        		printf LOG "q-- $query2 t-- $t_pdb $tm\n";
                        		#$t_pdb=$t_pdb.".pdb";
                        		#printf TARGET "$BU_RES_RENUM/$t_pdb\n";
                        		printf TARGET "$target_path\n";

                		}
			#	elsif($_=~/.*_p1\[/  && (substr($_,49,6) > $T_CUT))  # selecting good targets, cut-off can be changed
			#	{
			#		$tm = substr($_,49,6);
                        #                printf LOG "q-- $query2 t-- $t_pdb $tm\n";
                        #                $t_pdb=$t_pdb.".pdb";
                        #                printf TARGET "$BU_PISA/$t_pdb\n";
			#	}
			}
			
		}
	}
}
close FH1;
close FH2;
close TARGET;
close LOG;

my $kpax1 = time();
my $run_time1 = $kpax1 - $start_run;
print "First kpax run took $run_time1 seconds\n";


# Do full QS alignment of query with good targets

run_kpax_fullQS($query,$target_file);

my $kpax2 = time();
my $run_time2 = $kpax2 - $kpax1;
print "Second (Full QS) kpax run took $run_time2 seconds\n";



#OUTPUT FILE   (Reading from tmp_N_1, 2...)

my $tr_cnt=0;my $out_pat=$q_code."_tmp_N";

open(OUTwrite,">./QSalign_results/$output");
print OUTwrite "query_pdb\ttarget\tTM-Score\tM\tN\tI\tLen\n";

#open(OUTread ,"/tmp/$q_code/$q_code.ktops") or print STDERR "could not be opened, No such file  - $!\n";;

opendir (DIR, $logdir);
my @out_files = grep { -f "$logdir/$_" && /^$out_pat.*/ } readdir(DIR);

#print "logdir -  $logdir, outfiles -  @out_files\n";

foreach my$file (@out_files)
{
	chomp($file);
#print "out file $file\n";
	open(OUTread,"$logdir/$file") or print STDERR "outfile $file could not be opened, No such file  - $!\n";
	{
		my $line;my $tm_match; my $target_match;my $M_match; my $N_match; my $I_match; my $len; 
		while(<OUTread>)
		{
			if($_=~/Rank/)
			{
			$line=$.;  # getting the line no.
			last;
			}
	
		}

		$line=$line+2;
		seek OUTread,$line,0;  # start reading from line no. $line
		while(<OUTread>)
		{
	
			if($_=~/(\w\w\w\w_p{0,1}\d+)\[/)
			{
				$target_match = $1; 
				$tm_match = substr($_,41,6);$M_match = substr($_,55,5); $N_match = substr($_,61,5); $I_match = substr($_,67,5); $len = substr($_,73,5);
				if($tm_match > $::T_CUT)
				{
					$tr_cnt++;
					print OUTwrite "$q_pdb\t$target_match\t$tm_match\t$M_match\t$N_match\t$I_match\t$len\n";
				}
			}
		}
	}
}
if($tr_cnt > 0)
{
	print OUTwrite "These are the $tr_cnt targets that match the query with TM score above $::T_CUT. To get more, lower the TM score cut-off in file 'kpax.pm'\n";
	print OUTwrite "NOTE: Targets with TM score below 0.65 may not be similar to that of the query\n"; 
	print OUTwrite "To learn more about the output consult http://kpax.loria.fr/\n"; 
	#print OUTwrite " 'p1' represents structure (first) from PISA\n"; 

}
else
{
	print OUTwrite "There are 0 targets that match the query with TM score above $::T_CUT\n";
	print OUTwrite "You can lower the TM score cut-off in file 'kpax.pm' to get more targets, but targets with TM score below 0.65 may not be similar to that of the query\n"; 
}

close OUTread;
close OUTwrite;


##########  Sub routines ##########

### First KPAX, for selecting good targets###

sub run_kpax_good_targets{
my($q,$t)=@_;
my $target_path;
my $t_ori=$t;
#print "Inside first sub routine, kpax1, q- $q, t - $t\n";
if($t=~/_p\d/)
{
	$t=~s/_p\d/_1_A.pdb/;
	#$target_path = $BU_PISA;
	$target_path = $::PATH_BU_SPLIT;  #(will take the monomers from PDB only for the 1st kpax run, but have to keep track, for full QS align)
}
else
{
	$t=$t."_A.pdb";
	$target_path = $::PATH_BU_SPLIT;
}
#print " Inside first sub routine, kpax1, q-- $q t-- $t tpath -- $target_path\n";
#print STDERR "Running first alignment\n";
my $msg = `$::KPAX_EXECUTABLE $q $target_path/$t -sort=K -top=1000 -show=1000 -pdb -broken\n`;
#system("$KPAX_EXECUTABLE $q $target_path/$t");
#return $t_ori;
}


###Second KPAX for full QS alignment with good targets###

sub run_kpax_fullQS{
my($q,$tf)=@_;

print STDERR "Running 2nd full alignment\n";
open(TARGET,"$tf");
my @arr_target_file=<TARGET>;
close TARGET;
my $target_size=@arr_target_file;
print "There are $target_size targets found\n";

# FOR >1000 targets found, target file is splitted into _1, _2, ... and passed one by one

if($target_size > 900)
{
	my $j=1; my $count=0;my $tf1 = $tf."_"."$j";
	open(TARGET, ">$tf1");
	for(my $i =1; $i <= $target_size; $i++)
	{
		$count++;
		print (TARGET "$arr_target_file[$i]\n");
		if(($count == 900) && ($i < $target_size))
		{
			close TARGET;
			#$tf = "$tf._$j";
			system("perl ./00_EXE_KPAX_CORRES_modified.pl $q $tf1 $j");
			$j++;	$tf1 = $tf."_"."$j";
			
			open(TARGET, ">$tf1");
			$count=0;
		}
		elsif($count < 900 && $i == $target_size)
		{	
			close TARGET;
                        #$tf = "$tf._$j";
                        system("perl ./00_EXE_KPAX_CORRES_modified.pl $q $tf1 $j");
		}

	}

}
else
{
	system("perl ./00_EXE_KPAX_CORRES_modified.pl $q $tf 1");
}
}
