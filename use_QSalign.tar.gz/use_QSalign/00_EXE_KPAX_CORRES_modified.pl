#------------------------------------------------------------+
# Date    : 20/04/2014                                       |
# Authors : E. Levy                                          |
# Contact : emmanuel.levy@gmail.com                          |
#------------------------------------------------------------+
#
#
#
#

use strict ;
use warnings;
use File::Basename;
use Data::Dumper ;
use File::Copy
#require("../00_general/cplx_general.pm");
require("./kpax.pm");
#require("../00_general/general.pm");
#require("../00_general/html.pl");
#require("../00_general/3dcomplex_query.pm");
#require("../00_general/SQL.pl");
#require("../00_general/CPLX_STATIC.pl");

$ENV{KPAX_RESULTS} = '/tmp/';

## takes filepath for 2 PDB codes as argument, and:
## 1. aligns them using KPAX.
## 2. loads the aligned PDB files
## 3. establishes correspondances between chains
## 4. re-writes the PDB with the new chain names
## 5. re-executes KPAX on the newly written PDB files.

my ($FILE1, $FILE2, $NUM) = @ARGV;

my $PDB_LIST = [];

my $PDB1 = basename($FILE1, ".pdb");
print "file1 $FILE1 file2 $FILE2 pdb1 $PDB1 ";
my $ALI_PDB1 = $ENV{KPAX_RESULTS}."$PDB1/${PDB1}_query.pdb";
push @$PDB_LIST, $ALI_PDB1 ;
print "ALI_pdb1 $ALI_PDB1\n";
my $tmp1="./QSalign_LOG/".$PDB1."_tmp_".$NUM;
my $tmp2="./QSalign_LOG/".$PDB1."_tmp_N_".$NUM;

#print "   arr @$PDB_LIST\n";
########################################################## 1. aligns the original files using KPAX.
#print STDERR "$::KPAX_EXECUTABLE $FILE1 target=$FILE2 -sort=K -top=1000 -show=1000 -pdb > tmp_$NUM\n";
#my $msg = `$::KPAX_EXECUTABLE $FILE1 target=$FILE2 -sort=K -top=1000 -show=1000 -pdb > tmp_$NUM\n`;
my $msg = `$::KPAX_EXECUTABLE $FILE1 target=$FILE2 -sort=K -top=1000 -show=1000 -pdb > $tmp1\n`;
#my $msg = `$::KPAX_EXECUTABLE $FILE1 $FILE2 -sort=K -top=1000 -show=1000 -pdb > tmp_$NUM\n`;

my $KTOPS = $ENV{KPAX_RESULTS}.$PDB1."/$PDB1.ktops";

########################################################## 1.1 Checks that the alignements actually gave a result.
##########################################################     If the structure only contains alpha carbons for example,
##########################################################     then no file is written and I've got to abort.

if( -e "$KTOPS"){

    open(ISOK, "<$KTOPS");
    my @alllines = <ISOK>;
    if( $#alllines <= 1){
	exit(0);
    }

    rename $KTOPS, $KTOPS."2";
} else {
    print STDERR "File $KTOPS does not exists\n";
}

## Now loops over the target file.
open(IN_ALI,     "<$FILE2")    or die ("Couldn't open the file $FILE2 - $!\n");
#open(IN_ALI_NEW, ">${FILE2}2") or die ("Couldn't open the file ${FILE2}2 - $!\n");
open(IN_ALI_NEW, ">${FILE2}2") or die ("Couldn't open the file ${FILE2}2 - $!\n");


########################################################## 2. Loops over each lines from FILE2 (the input)
##########################################################    And creates the list of PDB files to go over.

while(<IN_ALI>){

    chomp($_);
    my $current_target = $_;
#print "Working on target -- $current_target \n";
    my $PDB2 = basename($current_target, ".pdb");
    my $ALI_PDB2 = $ENV{KPAX_RESULTS}."$PDB1/${PDB2}_$PDB1.pdb";

    if(-e $ALI_PDB2){
	print IN_ALI_NEW $ENV{KPAX_RESULTS}."$PDB1/pdbs/${PDB2}.pdb\n";
	push @$PDB_LIST, $ALI_PDB2 ;
    }

#     print STDERR "$ALI_PDB2\n";

}
     #print STDERR "$ALI_PDB2\n";

close(IN_ALI_NEW);

#$PDB_LIST = ["/tmp/2je4_1/2je4_1_2je4_1.pdb"];
#print Dumper($PDB_LIST);

my $pdbs = load_PDBs($PDB_LIST, 1);

# my @tmp = keys %$pdbs;
#print STDERR "KEYS = @tmp \n";
#print "PDBs = ".Dumper($pdbs);

########################################################## 3. establishes correspondances between chains
my %H_bdbh     = ();
my %H_bdbh_rev = ();
my %PDB_chain_corres  = ();
my %PDB_chain_corres2 = ();

my $H_ch_num_cor = map_chain_name_num($FILE1);
#print STDERR "Chain corres = ".Dumper($H_ch_num_cor);

my @chains1 = sort { $H_ch_num_cor->{$a} <=> $H_ch_num_cor->{$b} } keys %{$pdbs -> {$ALI_PDB1}} ;

my $cut_GNM  = 1;        # ---- cut-off to check correspondance between 2 residues (GNM view)

# getting the size of target file - SD
seek IN_ALI, 0, 0;
my $target_size = @{[<IN_ALI>]};
my $cnt=0;



seek IN_ALI, 0, 0;
while(<IN_ALI>){

    chomp($_);
    my $current_target = $_;
    $cnt++;	
    print "Working on target -- $current_target $cnt / $target_size good targets\n";
    my $PDB2 = basename($current_target, ".pdb");
    my $ALI_PDB2 = $ENV{KPAX_RESULTS}."$PDB1/${PDB2}_$PDB1.pdb";

    ###
    ### The chains in the array need to be ordered in increasing numbers.
    ###
    my @chains2 = keys %{$pdbs -> {$ALI_PDB2}} ;

    my ($ch_i, $ch_j, $x, $y, $z);

    for $ch_i (0..$#chains1){

	my @table = @{$pdbs->{$ALI_PDB1}->{$chains1[$ch_i]}->{"x"}};
	@table = sort {$a->[1] <=> $b->[1]} @table ;

	#print STDERR "$ALI_PDB2 $ch_i ($chains1[$ch_i]) - $#table residues to match among ".@chains2." chains from $ALI_PDB2\n";
	
	## Foreach resid of PDB1, I need to check all chains in PDB2
	foreach my $resid_num (@table){

	    $x = $pdbs->{$ALI_PDB1}->{$chains1[$ch_i]}->{$resid_num->[1]}->{"CA"}->{"x"} ;
	    $y = $pdbs->{$ALI_PDB1}->{$chains1[$ch_i]}->{$resid_num->[1]}->{"CA"}->{"y"} ;
	    $z = $pdbs->{$ALI_PDB1}->{$chains1[$ch_i]}->{$resid_num->[1]}->{"CA"}->{"z"} ;

	 #   print STDERR "X=$x, Y=$y, Z=$z\n";
	    
	    for $ch_j (@chains2){

		# ---- Here we look at residues which Calphas are closer than cut_GNM angstrom
		my $contact_list_big_rough = get_close($pdbs, $ALI_PDB2, $x, $y, $z, $cut_GNM, $ch_j);
		
		if($#{$contact_list_big_rough} >= 0){

		    #print STDERR "yy\n";

		    if( exists $PDB_chain_corres{$ALI_PDB2}->{$ch_i}->{$ch_j} ){
			$PDB_chain_corres{$ALI_PDB2}->{$ch_i}->{$ch_j}++;
		    } else {
			$PDB_chain_corres{$ALI_PDB2}->{$ch_i}->{$ch_j}=1;
		    }

		    if( exists $PDB_chain_corres2{$ALI_PDB2}->{$ch_j}->{$ch_i} ){
			$PDB_chain_corres2{$ALI_PDB2}->{$ch_j}->{$ch_i}++;
		    } else {
			$PDB_chain_corres2{$ALI_PDB2}->{$ch_j}->{$ch_i}=1;
		    }

		} 
	    }
	}
    }	  

#print STDERR "ok after get close\n";
   # print Dumper($PDB_chain_corres{$ALI_PDB2});

    ### Process the chain corres HASH to return a new HASH of the following format:
    ### H_bdbh     --> {PDB} --> { NUMBER } = CHAIN
    ### H_bdbh_rev --> {PDB} --> { CHAIN  } = NUMBER
    
    ($H_bdbh{$ALI_PDB2}, $H_bdbh_rev{$ALI_PDB2}) = BDBH($PDB_chain_corres{$ALI_PDB2}, $PDB_chain_corres2{$ALI_PDB2}) ;
    
    #print STDERR "H BDBH:";    
    #print Dumper(\%H_bdbh);    
    #print STDERR "H BDBH REV:";    
    #print Dumper(\%H_bdbh_rev);

    ###
    ### Here I've got the info for corresponding chains and now need to add info for non-corresponding chains.
    ### @chains2 contains the chain names of the PDBs to re-write so I need to loop over @chains2, if exists OK, if not add incremental numbers
    ###

    my @vals1 = keys %{$H_bdbh{$ALI_PDB2}};
    my $start_value = MAX(\@vals1 );
    foreach my $ch2 (@chains2){

	if( !exists $H_bdbh_rev{$ALI_PDB2}->{$ch2} ){
	    $start_value++;
	    $H_bdbh{    $ALI_PDB2} -> {$start_value} = $ch2;
	    $H_bdbh_rev{$ALI_PDB2} -> {$ch2}         = $start_value;
	}    
    }
}

#print "ok after BDBH\n";
########################################################## 4. re-writes the PDB with the new chain names
write_PDB_kpax($pdbs, \%H_bdbh);


########################################################## 5. re-executes KPAX on the newly written PDB files.
$msg = `$::KPAX_EXECUTABLE $FILE1 target=${FILE2}2 -sort=K -top=1000 -show=1000 -nopdb -nokpax > $tmp2\n`;

exit(1);

# $VAR1 = {
#           '/tmp/1ohz/1ohz_query.pdb' => {
#                                           'F' => {
#                                                    '33' => {
#                                                              'O' => {
#                                                                       'y' => '-71.114',
#                                                                       'x' => '-44.396',
#                                                                       'z' => '27.561'
#                                                                     },
#                                                              'Rname' => 'LYS',
#                                                              'N' => {
#                                                                       'y' => '-71.185',
#                                                                       'x' => '-41.978',
#                                                                       'z' => '30.131'
#                                                                     },
#                                                              'CB' => {
#                                                                        'y' => '-72.201',
#                                                                        'x' => '-44.152',
#                                                                        'z' => '30.662'
#                                                                      },
#                                                              'CE' => {
#                                                                        'y' => '-75.392',
#                                                                        'x' => '-44.656',
#                                                                        'z' => '32.759'
#                                                                      },
#                                                              'CD' => {
#                                                                        'y' => '-74.084',
#                                                                        'x' => '-45.008',
#                                                                        'z' => '32.075'
